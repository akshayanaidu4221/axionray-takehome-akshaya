# AxionRay Data Analytics Assignment - Complete Solution

## Overview
This repository contains a comprehensive automated solution for the AxionRay Data Analytics assignment, implementing both Task 1 (Data Tagging) and Task 2 (Data Analysis & Insights).

## Files Generated

### Task 1 - Data Tagging
- **Task1_Tagged.xlsx**: Complete dataset with automatically assigned tags
- **Task1_Summary.txt**: Detailed summary report explaining the tagging methodology and results

### Task 2 - Data Analysis & Insights  
- **Task2_Cleaned.xlsx**: Cleaned and processed dataset
- **Task2_Visualizations.png**: Comprehensive visualization suite with 6 key charts
- **Task2_Report.txt**: Detailed 2-page analysis report with insights and recommendations

### Source Code
- **axionray_data_analytics_solution.py**: Complete Python solution with all functionality

## Key Features

### Task 1 Implementation
- ✅ Fuzzy string matching using FuzzyWuzzy library
- ✅ NLP-based text analysis combining multiple fields
- ✅ Automatic tagging of Root Cause, Symptom Conditions, Symptom Components, Fix Conditions, and Fix Components
- ✅ 100% success rate for most tag categories
- ✅ Comprehensive summary report with methodology explanation

### Task 2 Implementation
- ✅ Complete column-wise data analysis (52 columns analyzed)
- ✅ Advanced data cleaning (missing values, outliers, categorical inconsistencies)
- ✅ Top 5 critical columns identification with scoring algorithm
- ✅ 6 comprehensive visualizations (histograms, bar charts, scatter plots, pie charts)
- ✅ TF-IDF text analysis for free-text columns
- ✅ Actionable insights and recommendations
- ✅ 98.08% data quality achieved

## Technical Stack
- **Python 3.11+**
- **Pandas**: Data manipulation and analysis
- **NumPy**: Numerical computations
- **Matplotlib & Seaborn**: Data visualization
- **FuzzyWuzzy**: Fuzzy string matching
- **Scikit-learn**: TF-IDF text analysis
- **OpenPyXL**: Excel file handling

## Usage
Simply run the main script:
```bash
python axionray_data_analytics_solution.py
```

## Results Summary
- **Task 1**: Successfully tagged 80% of records across all categories
- **Task 2**: Analyzed 100 records across 52 columns with comprehensive insights
- **Data Quality**: Improved from 96.5% to 98.08% completeness
- **Visualizations**: 6 key charts highlighting cost patterns, regional performance, and vehicle usage
- **Text Analysis**: Extracted key terms from customer complaints and repair descriptions

## Key Insights Discovered
1. Significant variation in repair costs across regions and platforms
2. Clear correlation between vehicle mileage and repair costs
3. Regional performance differences in dealer service quality
4. Steering wheel issues as the most common complaint type
5. Opportunities for predictive maintenance based on usage patterns

---
*Solution developed for AxionRay Data Analytics Assignment*
